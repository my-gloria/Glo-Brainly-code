#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define FILE_NAME "UBUDEHE.txt"

typedef struct {
    char nationalID[20];
    char names[50];
    char gender[5];
    char phone[20];
    char cell[30];
    char village[30];
    char startDate[15];
} Person;

/* ---------------- VALIDATION FUNCTIONS ---------------- */

int isAlphaString(char str[]) {
    for (int i = 0; str[i] != '\0'; i++) {
        if (!isalpha(str[i]) && str[i] != ' ') {
            return 0;
        }
    }
    return 1;
}

int isDigitString(char str[]) {
    for (int i = 0; str[i] != '\0'; i++) {
        if (!isdigit(str[i])) {
            return 0;
        }
    }
    return 1;
}

int validDate(char str[]) {
    for (int i = 0; str[i] != '\0'; i++) {
        if (!isdigit(str[i]) && str[i] != '-') {
            return 0;
        }
    }
    return 1;
}

int validGender(char g[]) {
    return (strcmp(g, "M") == 0 || strcmp(g, "F") == 0);
}

/* ---------------- ADD RECORD ---------------- */

void addRecord() {
    FILE *fp = fopen(FILE_NAME, "a");
    Person p;

    printf("Enter National ID: ");
    scanf("%s", p.nationalID);

    if (!isDigitString(p.nationalID)) {
        printf("Invalid National ID! Numbers only.\n");
        return;
    }

    printf("Enter Names: ");
    scanf(" %[^\n]", p.names);

    if (!isAlphaString(p.names)) {
        printf("Invalid Name! Letters only.\n");
        return;
    }

    printf("Enter Gender (M/F): ");
    scanf("%s", p.gender);

    if (!validGender(p.gender)) {
        printf("Invalid Gender! Only M or F allowed.\n");
        return;
    }

    printf("Enter Phone: ");
    scanf("%s", p.phone);

    if (!isDigitString(p.phone)) {
        printf("Invalid Phone! Numbers only.\n");
        return;
    }

    printf("Enter Cell: ");
    scanf("%s", p.cell);

    if (!isDigitString(p.cell)) {
        printf("Invalid Cell! Numbers only.\n");
        return;
    }

    printf("Enter Village: ");
    scanf("%s", p.village);

    printf("Enter Starting Date (YYYY-MM-DD): ");
    scanf("%s", p.startDate);

    if (!validDate(p.startDate)) {
        printf("Invalid Date! Use numbers and '-'\n");
        return;
    }

    fprintf(fp, "%s %s %s %s %s %s %s\n",
            p.nationalID, p.names, p.gender,
            p.phone, p.cell, p.village, p.startDate);

    fclose(fp);

    printf("Record added!\n");
}

/* ---------------- VIEW RECORDS ---------------- */

void viewRecords() {
    FILE *fp = fopen(FILE_NAME, "r");
    Person p;

    if (fp == NULL) {
        printf("No records found!\n");
        return;
    }

    printf("\nNationalID\t Names\t Gender\t Phone\t Cell\t Village\t StartDate\n");

    while (fscanf(fp, "%s %s %s %s %s %s %s",
                  p.nationalID, p.names, p.gender,
                  p.phone, p.cell, p.village, p.startDate) != EOF) {

        printf("%s\t %s\t %s\t %s\t %s\t %s\t %s\n",
               p.nationalID, p.names, p.gender,
               p.phone, p.cell, p.village, p.startDate);
    }

    fclose(fp);
}

/* ---------------- EDIT RECORD ---------------- */

void editRecord() {
    FILE *fp = fopen(FILE_NAME, "r");
    FILE *temp = fopen("temp.txt", "w");

    Person p;
    char id[20];
    int found = 0;

    printf("Enter National ID to edit: ");
    scanf("%s", id);

    while (fscanf(fp, "%s %s %s %s %s %s %s",
                  p.nationalID, p.names, p.gender,
                  p.phone, p.cell, p.village, p.startDate) != EOF) {

        if (strcmp(p.nationalID, id) == 0) {
            found = 1;

            printf("Enter new Names: ");
            scanf(" %[^\n]", p.names);

            if (!isAlphaString(p.names)) {
                printf("Invalid Name!\n");
                continue;
            }

            printf("Enter new Gender (M/F): ");
            scanf("%s", p.gender);

            if (!validGender(p.gender)) {
                printf("Invalid Gender!\n");
                continue;
            }

            printf("Enter new Phone: ");
            scanf("%s", p.phone);

            if (!isDigitString(p.phone)) {
                printf("Invalid Phone!\n");
                continue;
            }

            printf("Enter new Cell: ");
            scanf("%s", p.cell);

            if (!isDigitString(p.cell)) {
                printf("Invalid Cell!\n");
                continue;
            }

            printf("Enter new Village: ");
            scanf("%s", p.village);

            printf("Enter new Starting Date: ");
            scanf("%s", p.startDate);

            if (!validDate(p.startDate)) {
                printf("Invalid Date!\n");
                continue;
            }
        }

        fprintf(temp, "%s %s %s %s %s %s %s\n",
                p.nationalID, p.names, p.gender,
                p.phone, p.cell, p.village, p.startDate);
    }

    fclose(fp);
    fclose(temp);

    remove(FILE_NAME);
    rename("temp.txt", FILE_NAME);

    if (found)
        printf("Record updated!\n");
    else
        printf("Record not found!\n");
}

/* ---------------- DELETE RECORD ---------------- */

void deleteRecord() {
    FILE *fp = fopen(FILE_NAME, "r");
    FILE *temp = fopen("temp.txt", "w");

    Person p;
    char id[20];
    int found = 0;

    printf("Enter National ID to delete: ");
    scanf("%s", id);

    while (fscanf(fp, "%s %s %s %s %s %s %s",
                  p.nationalID, p.names, p.gender,
                  p.phone, p.cell, p.village, p.startDate) != EOF) {

        if (strcmp(p.nationalID, id) == 0) {
            found = 1;
            continue;
        }

        fprintf(temp, "%s %s %s %s %s %s %s\n",
                p.nationalID, p.names, p.gender,
                p.phone, p.cell, p.village, p.startDate);
    }

    fclose(fp);
    fclose(temp);

    remove(FILE_NAME);
    rename("temp.txt", FILE_NAME);

    if (found)
        printf("Record deleted!\n");
    else
        printf("Record not found!\n");
}

/* ---------------- MAIN MENU ---------------- */

int main() {
    int choice;

    do {
        printf("\n=== UBUDEHE Records Management(Mayange Sector, Bugesera) ===\n");
        printf("1.Add New Record\n");
        printf("2.View All Records\n");
        printf("3.Edit Existing Record\n");
        printf("4.Delete Record\n");
        printf("0.Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1: addRecord(); break;
            case 2: viewRecords(); break;
            case 3: editRecord(); break;
            case 4: deleteRecord(); break;
            case 0: printf("Goodbye!\n"); break;
            default: printf("Invalid choice!\n");
        }

    } while (choice != 0);

    return 0;
}
